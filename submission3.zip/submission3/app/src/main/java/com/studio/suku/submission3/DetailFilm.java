package com.studio.suku.submission3;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailFilm extends AppCompatActivity {

    public static final String EXTRA_DATA = "extra_data";
    TextView title, desc;
    ImageView img, bg;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_film);

        title = findViewById(R.id.judul);
        desc = findViewById(R.id.desc);
        img = findViewById(R.id.poster);
        bg = findViewById(R.id.imageView);
        ItemFilm itemFilm = getIntent().getParcelableExtra(EXTRA_DATA);

        title.setText(itemFilm.getName());
        desc.setText(itemFilm.getDesc());

        Picasso.get().load(itemFilm.getPath_img()).into(img);
        Picasso.get().load("https://pro2-bar-s3-cdn-cf5.myportfolio.com/b23f9db4e2c38f9f16365bcd65fd2b3a/66fe9eea-2292-4c41-8061-70d5c500aa0c_rw_1920.png?h=0e924c63656a2b332eb2e48c78b94a69").into(bg);

    }
}
