package com.studio.suku.submission2;


import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class FilmFragment extends Fragment {

    private RecyclerView list;
    View v;
    private ArrayList<Item> data = new ArrayList<>();

    public FilmFragment() {
        // Required empty public constructor
    }



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //Fragment Film
        v =  inflater.inflate(R.layout.fragment_film, container, false);
        // Inflate the layout for this fragment
        return v;

    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        list = v.findViewById(R.id.list_film);
        Log.d("Datanya", String.valueOf(Data.getListData()));
        data.addAll(Data.getListData());
        list.setHasFixedSize(true);
        list.setLayoutManager(new GridLayoutManager(getActivity(), 2));
        ItemAdapter adapter = new ItemAdapter(getActivity());
        adapter.setItems(data);
        list.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        super.onViewCreated(view, savedInstanceState);
    }
}
