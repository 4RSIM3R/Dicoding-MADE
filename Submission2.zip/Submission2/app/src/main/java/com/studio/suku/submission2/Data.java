package com.studio.suku.submission2;

import java.util.ArrayList;
import java.util.Locale;

public class Data {

    //Kumpulan Dummy Data

    public static String[][] engData = new String[][]{
            {"Bumblebee",
                    "On the run in the year 1987, Bumblebee finds refuge in a junkyard in a small Californian beach town. Charlie, on the cusp of turning 18 and trying to find her place in the world, discovers Bumblebee, battle-scarred and broken. When Charlie revives him, she quickly learns this is no ordinary yellow VW bug.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/fw02ONlDhrYjTSZV8XO6hhU3ds3.jpg"},
            {"Avengers Infinity War",
                    "As the Avengers and their allies have continued to protect the world from threats too large for any one hero to handle, a new danger has emerged from the cosmic shadows: Thanos. A despot of intergalactic infamy, his goal is to collect all six Infinity Stones, artifacts of unimaginable power, and use them to inflict his twisted will on all of reality. Everything the Avengers have fought for has led up to this moment - the fate of Earth and existence itself has never been more uncertain.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg"},
            {"Aquaman",
                    "Once home to the most advanced civilization on Earth, Atlantis is now an underwater kingdom ruled by the power-hungry King Orm. With a vast army at his disposal, Orm plans to conquer the remaining oceanic people and then the surface world. Standing in his way is Arthur Curry, Orm's half-human, half-Atlantean brother and true heir to the throne.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/5Kg76ldv7VxeX9YlcQXiowHgdX6.jpg"},
            {"Venom",
                    "Investigative journalist Eddie Brock attempts a comeback following a scandal, but accidentally becomes the host of Venom, a violent, super powerful alien symbiote. Soon, he must rely on his newfound powers to protect the world from a shadowy organization looking for a symbiote of their own.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/2uNW4WbgBXL25BAbXGLnLqX71Sw.jpg"},
            {"Black Panther",
                    "King T'Challa returns home from America to the reclusive, technologically advanced African nation of Wakanda to serve as his country's new leader. However, T'Challa soon finds that he is challenged for the throne by factions within his own country as well as without. Using powers reserved to Wakandan kings, T'Challa assumes the Black Panther mantel to join with girlfriend Nakia, the queen-mother, his princess-kid sister, members of the Dora Milaje (the Wakandan 'special forces') and an American secret agent, to prevent Wakanda from being dragged into a world war.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/uxzzxijgPIY7slzFvMotPv8wjKA.jpg"},
            {"Mortal Engines",
                    "Many thousands of years in the future, Earth’s cities roam the globe on huge wheels, devouring each other in a struggle for ever diminishing resources. On one of these massive traction cities, the old London, Tom Natsworthy has an unexpected encounter with a mysterious young woman from the wastelands who will change the course of his life forever.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/iteUvQKCW0EqNQrIVzZGJntYq9s.jpg"},
    };

    public static String[][] indData = new String[][]{
            {"Bumblebee",
                    "Dalam pelarian pada tahun 1987, Bumblebee menemukan tempat perlindungan di tempat barang rongsokan di kota pantai kecil California. Charlie, di puncak usia 18 dan berusaha menemukan tempatnya di dunia, menemukan Bumblebee, bekas luka pertempuran dan patah. Ketika Charlie menghidupkannya, dia dengan cepat mengetahui bahwa ini bukan bug VW kuning biasa.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/fw02ONlDhrYjTSZV8XO6hhU3ds3.jpg"},
            {"Avengers Infinity War",
                    "Karena Avengers dan sekutunya terus melindungi dunia dari ancaman yang terlalu besar untuk ditangani oleh seorang pahlawan, bahaya baru telah muncul dari bayangan kosmik: Thanos. Seorang lalim penghujatan intergalaksi, tujuannya adalah untuk mengumpulkan semua enam Batu Infinity, artefak kekuatan yang tak terbayangkan, dan menggunakannya untuk menimbulkan kehendak memutar pada semua realitas. Segala sesuatu yang telah diperjuangkan oleh Avengers telah berkembang hingga saat ini - nasib Bumi dan keberadaannya sendiri tidak pernah lebih pasti.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/7WsyChQLEftFiDOVTGkv3hFpyyt.jpg"},
            {"Aquaman",
                    "Dulunya merupakan rumah bagi peradaban paling maju di Bumi, Atlantis sekarang merupakan kerajaan bawah laut yang diperintah oleh Raja Orm yang haus kekuasaan. Dengan pasukan yang sangat besar, Orm berencana untuk menaklukkan orang-orang samudera yang tersisa dan kemudian ke permukaan dunia. Yang menghalangi jalannya adalah Arthur Curry, saudara tiri manusia setengah manusia Orm dan pewaris sejati takhta.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/5Kg76ldv7VxeX9YlcQXiowHgdX6.jpg"},
            {"Venom",
                    "Jurnalis investigasi Eddie Brock mencoba untuk kembali setelah skandal, tetapi secara tidak sengaja menjadi tuan rumah Venom, seorang simbiot alien yang sangat kuat dan sakti. Segera, ia harus mengandalkan kekuatan barunya untuk melindungi dunia dari organisasi bayangan yang mencari simbiosis mereka sendiri.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/2uNW4WbgBXL25BAbXGLnLqX71Sw.jpg"},
            {"Black Panther",
                    "Raja T'Challa pulang dari Amerika ke negara Wakanda yang tertutup dan berteknologi maju untuk melayani sebagai pemimpin baru negaranya. Namun, T'Challa segera menemukan bahwa ia ditantang untuk naik takhta oleh faksi di negaranya sendiri maupun di luar. Menggunakan kekuatan yang disediakan untuk raja-raja Wakandan, T'Challa mengasumsikan mantel Black Panther untuk bergabung dengan pacar Nakia, ibu-ratu, saudara perempuan-anak kandungnya, anggota Dora Milaje (pasukan khusus 'Wakandan') dan seorang agen rahasia Amerika. , untuk mencegah Wakanda diseret ke dalam perang dunia.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/uxzzxijgPIY7slzFvMotPv8wjKA.jpg"},
            {"Mortal Engines",
                    "Beribu-ribu tahun di masa depan, kota-kota di bumi menjelajah dunia dengan roda besar, saling melahap dalam perjuangan untuk sumber daya yang semakin berkurang. Di salah satu kota traksi besar ini, London tua, Tom Natsworthy mengalami perjumpaan tak terduga dengan seorang wanita muda misterius dari daerah terlantar yang akan mengubah jalan hidupnya selamanya.",
                    "https://image.tmdb.org/t/p/w600_and_h900_bestv2/iteUvQKCW0EqNQrIVzZGJntYq9s.jpg"},
    };

    public static String[][] tvInd = new String[][]{
            {
                "86",
                    "86 adalah program informasi dan investigasi yang diproduksi secara kerjasama antara NET. dan Kepolisian Negara Republik Indonesia mengenai keseharian beberapa anggota polisi. Nama program ini sendiri berasal dari kode sandi POLRI yang berarti dimengerti atau roger that ",
                    "https://ratracecycle.files.wordpress.com/2018/08/net-86-progress-31.jpg?w=1400&h=9999"
            },
            {
                "Ini Talkshow",
                    "Ini Talkshow adalah acara talkshow/gelar wicara yang dikemas dengan suasana santai. Membahas persoalan hangat yang ada di masyarakat dengan cara sederhana. Di acara ini juga akan memperlihatkan suasana rumah dan karakter-karakter yang ada di rumah tersebut.",
                    "http://cdn.netmedia.co.id/ott/image/2016/07/21/5745722c06451.jpg"
            },
            {
                "Sarach Sechan",
                    "Sarah Sechan adalah sebuah acara talkshow Indonesia yang dibawakan oleh Sarah Sechan di NET. Setiap acaranya menyampaikan tema tertentu yang diselingi dengan lawakan. yang akan berbincang-bincang dengan bintang tamu dan akan membahas sesuatu yang belum diketahui banyak orang",
                    "https://yt3.ggpht.com/a/AGF-l79uebWhUBJqHzJNMz4PNHKI7-wrJ6i8fru0Ig=s900-mo-c-c0xffffffff-rj-k-no"
            },
            {
                "Indonesia Morning Show",
                    "Indonesia Morning Show adalah program gelar wicara dan berita yang ditayangkan oleh NET. yang menampilkan berbagai paket informasi terkini seperti: Hard News, Light News, Entertainment dan Olahraga. Acara ini siaran perdana sejak Sabtu, 18 Mei 2013, ketika NET. pertama kali melakukan siaran percobaan",
                    "https://yt3.ggpht.com/a/AGF-l78DDIpWyJyfNXbIwWqdfTiZUuavutMEF1I2xQ=s900-mo-c-c0xffffffff-rj-k-no"
            },
            {
                "Garuda",
                    "Garuda adalah sebuah program news magazine tentang kebanggaan, kecintaan dan semangat pengabdian anak bangsa terhadap negara dan tanah airnya. Garuda mengangkat aktivitas, profil, sisi lain dan cerita. Di balik sosok prajurit yang jarang diketahui public, Garuda bertujuan untuk menumbuhkan kebanggaan dan kecintaan pada tni serta memupuk rasa cinta tanah air.",
                    "https://yt3.ggpht.com/a/AGF-l7-PneJQG1NMd2ss70KzHOvERQTed1sZh8PpzA=s900-mo-c-c0xffffffff-rj-k-no"
            },
            {
                "Tonight Show",
                    "Tonight Show adalah sebuah gelar wicara/talkshow malam berdasarkan lisensi dari The Tonight Show Starring Jimmy Fallon. Pembawa acaranya adalah Vincent Rompies, Desta, Hesti Purwadinata dan Enzy Storia.",
                    "https://cdn.idntimes.com/content-images/community/2018/05/1525264288482-470819ddc6a3c32f61fdaa7d75ee9ce7.jpeg"
            }
    };

    public static String[][] tvEng = new String[][]{
            {
                    "86",
                    "86 is an information and investigation program produced in collaboration between NET. and the Republic of Indonesia National Police regarding the daily lives of several police officers. The name of the program itself comes from the POLRI passcode which means understandable or roger that ",
                    "https://ratracecycle.files.wordpress.com/2018/08/net-86-progress-31.jpg?w=1400&h=9999"
            },
            {
                    "Ini Talkshow",
                    "This talk show is a talk show / talk show that is packed with a relaxed atmosphere. Discussing the hot issues that exist in the community in a simple way. This event will also show the atmosphere of the house and the characters in the house.",
                    "http://cdn.netmedia.co.id/ott/image/2016/07/21/5745722c06451.jpg"
            },
            {
                    "Sarach Sechan",
                    "Sarah Sechan is an Indonesian talk show hosted by Sarah Sechan on NET. Each program conveys certain themes interspersed with jokes. who will chat with guest stars and will discuss something that is unknown to many people",
                    "https://yt3.ggpht.com/a/AGF-l79uebWhUBJqHzJNMz4PNHKI7-wrJ6i8fru0Ig=s900-mo-c-c0xffffffff-rj-k-no"
            },
            {
                    "Indonesia Morning Show",
                    "The Indonesia Morning Show is a speech degree program and news broadcast by NET. which features various updated information packages such as: Hard News, Light News, Entertainment and Sports. This program premiered since Saturday, May 18, 2013, when NET. first broadcast the experiment",
                    "https://yt3.ggpht.com/a/AGF-l78DDIpWyJyfNXbIwWqdfTiZUuavutMEF1I2xQ=s900-mo-c-c0xffffffff-rj-k-no"
            },
            {
                    "Garuda",
                    "Garuda is a news magazine program about pride, love and passion for the dedication of the nation's children to their country and homeland. Garuda raises activities, profiles, other sides and stories. Behind a soldier who is rarely known to the public, Garuda aims to foster pride and love for this and foster a sense of love for the country.",
                    "https://yt3.ggpht.com/a/AGF-l7-PneJQG1NMd2ss70KzHOvERQTed1sZh8PpzA=s900-mo-c-c0xffffffff-rj-k-no"
            },
            {
                    "Tonight Show",
                    "Tonight Show is a night talk / talk show based on a license from The Tonight Show Starring Jimmy Fallon. The show host is Vincent Rompies, Desta, Hesti Purwadinata and Enzy Storia.",
                    "https://cdn.idntimes.com/content-images/community/2018/05/1525264288482-470819ddc6a3c32f61fdaa7d75ee9ce7.jpeg"
            }
    };

    public static ArrayList<Item> getListData(){
        ArrayList<Item> list = new ArrayList<>();
        //Percobaan Lurd
        //Kita Deteksi Source Language Nya dulu
        boolean isEng = Locale.getDefault().getLanguage().equals("en");
        if (isEng) {
            for (String[] aData : engData){
                Item item = new Item();
                item.setName(aData[0]);
                item.setDecs(aData[1]);
                item.setPhoto(aData[2]);
                //Janga Kelupaan Ini
                list.add(item);
            }
        }
        else {
            for (String[] aData : indData){
                Item item = new Item();
                item.setName(aData[0]);
                item.setDecs(aData[1]);
                item.setPhoto(aData[2]);
                //Janga Kelupaan Ini
                list.add(item);
            }
        }
        return list;
    }

    public static ArrayList<Item> getListTv(){
        ArrayList<Item> list = new ArrayList<>();
        boolean isEng = Locale.getDefault().getLanguage().equals("en");
            if (isEng){
                for (String aData[] : tvEng){
                    Item item = new Item();
                    item.setName(aData[0]);
                    item.setDecs(aData[1]);
                    item.setPhoto(aData[2]);
                    list.add(item);
                }
            }
            else {
                for (String[] aData : tvInd){
                    Item item = new Item();
                    item.setName(aData[0]);
                    item.setDecs(aData[1]);
                    item.setPhoto(aData[2]);
                    list.add(item);
                }
            }
        return list;
    }

}
