package com.studio.suku.submission2;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class TvAdapter extends RecyclerView.Adapter<TvAdapter.Holder> {
    //Adapter Untuk List TV
    Context context;
    private ArrayList<Item> items;

    private ArrayList<Item> getItems(){
        return items;
    }

    public TvAdapter(Context context){
        this.context = context;
    }

    public void setItems(ArrayList<Item> items){
        this.items = items;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item, viewGroup, false);
        return new Holder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, final int i) {
        Glide.with(context).load(items.get(i).getPhoto()).apply(new RequestOptions()).into(holder.Image);
        holder.Image.setOnClickListener(new CustomOnItemClickListener(i, new CustomOnItemClickListener.OnItemClickCallback() {
            @Override
            public void onItemClicked(View view, int position) {
                Intent move = new Intent(context, Detail_tv.class);
                Item item = new Item();
                item.setName(items.get(i).getName());
                item.setDecs(items.get(i).getDecs());
                item.setPhoto(items.get(i).getPhoto());
                move.putExtra(Detail_tv.EXTRA_DETAIL, item);
                context.startActivity(move);
            }
        }));
    }

    @Override
    public int getItemCount() {
        if (getItems() != null){
            return getItems().size();
        }
        else {
            return 0;
        }
    }

    public class Holder extends RecyclerView.ViewHolder {
        ImageView Image;
        public Holder(@NonNull View itemView) {
            super(itemView);
            Image = itemView.findViewById(R.id.img_item_photo);
        }
    }
}
