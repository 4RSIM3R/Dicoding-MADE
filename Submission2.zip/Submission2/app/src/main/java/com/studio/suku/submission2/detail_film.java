package com.studio.suku.submission2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class detail_film extends AppCompatActivity {
    public static final String EXTRA_DATA = "extra_data";
    TextView title, syn;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_film);
        //Menggunakan Parcelable
        Item item = getIntent().getParcelableExtra(EXTRA_DATA);
        title = findViewById(R.id.txt_title_film);
        syn = findViewById(R.id.txt_desc_film);
        img = findViewById(R.id.img_detail_film);
        syn.setText(item.getDecs());
        title.setText(item.getName());

        Glide.with(detail_film.this).load(item.getPhoto()).apply(new RequestOptions()).into(img);

    }
}
