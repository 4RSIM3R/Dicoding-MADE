package com.studio.suku.submission2;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

public class Detail_tv extends AppCompatActivity {
    public static final String EXTRA_DETAIL = "extra_detail";
    TextView title, desc;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_tv);
        title = findViewById(R.id.txt_title);
        desc = findViewById(R.id.txt_desc);
        img = findViewById(R.id.img_detail_tv);
        //Menggunakan Parcelable
        Item item = getIntent().getParcelableExtra(EXTRA_DETAIL);

        title.setText(item.getName());
        desc.setText(item.getDecs());

        Glide.with(Detail_tv.this).load(item.getPhoto()).into(img);
    }
}
