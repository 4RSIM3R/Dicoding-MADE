package com.studio.suku.submission1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class Detail_film extends AppCompatActivity {
    TextView nama, desc;
    ImageView gambar;
    public static final String Extra_Object = "extra_person";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_film);
        nama = findViewById(R.id.nama);
        desc = findViewById(R.id.desc);
        gambar = findViewById(R.id.gambar);
        Pindah pindah = getIntent().getParcelableExtra(Extra_Object);
        nama.setText(pindah.getNama());
        desc.setText(pindah.getResensi());
        gambar.setImageResource(pindah.getPhoto());

    }
}
