package com.studio.suku.submission1;

import android.os.Parcel;
import android.os.Parcelable;

public class Pindah implements Parcelable {
    private int photo;
    private String nama;
    private String resensi;

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getResensi() {
        return resensi;
    }

    public void setResensi(String resensi) {
        this.resensi = resensi;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(this.photo);
        dest.writeString(this.nama);
        dest.writeString(this.resensi);
    }

    public Pindah() {
    }

    protected Pindah(Parcel in) {
        this.photo = in.readInt();
        this.nama = in.readString();
        this.resensi = in.readString();
    }

    public static final Parcelable.Creator<Pindah> CREATOR = new Parcelable.Creator<Pindah>() {
        @Override
        public Pindah createFromParcel(Parcel source) {
            return new Pindah(source);
        }

        @Override
        public Pindah[] newArray(int size) {
            return new Pindah[size];
        }
    };
}
