package com.studio.suku.submission1;

public class Film {
    //Setter Getter Nya di sini yah pak
    private int photo;
    private String nama;
    private String resensi;

    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getResensi() {
        return resensi;
    }

    public void setResensi(String resensi) {
        this.resensi = resensi;
    }
}
